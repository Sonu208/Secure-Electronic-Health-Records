import React from "react";
import { useParams } from "react-router-dom";
const InsurerDashBoard = () => {
  const { address } = useParams();

  return (
    <div>
      <div> Insurer dashboard</div>
      <p>Hello Insurer at address {address}</p>
    </div>
  );
};

export default InsurerDashBoard;
