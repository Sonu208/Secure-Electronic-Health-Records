import React, { useState } from "react";
import { Web3Storage } from "web3.storage";

function PdfViewer() {
  const [file, setFile] = useState(null);
  const [cid, setCid] = useState(null);
  const [retrievedFileURL, setRetrievedFileURL] = useState(null);

  const client = new Web3Storage({
    token:
      "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJkaWQ6ZXRocjoweDgyNDdFZDdiNGU5OWU2NGNjRUVGMjczOERBYzREQzNkRUM4YTJkZTAiLCJpc3MiOiJ3ZWIzLXN0b3JhZ2UiLCJpYXQiOjE2OTgyMjg0OTIyMzQsIm5hbWUiOiJpcGZzX3Rlc3RpbmcifQ.fY8HvEANqxvUv56pGyUqVU1X7PDRLsV6FN22eamNlmo",
  });

  const onFileChange = (event) => {
    setFile(event.target.files[0]);
  };

  const uploadToWeb3 = async () => {
    if (!file) return;

    const cid = await client.put([file]);
    setCid(cid);
  };

  const retrieveFromWeb3 = async () => {
    if (!cid) return;

    const retrieved = await client.get(cid);
    if (!retrieved) {
      console.error("Failed to retrieve file");
      return;
    }

    const fileBlob = new Blob([await retrieved.arrayBuffer()], {
      type: "application/pdf",
    });
    const fileURL = URL.createObjectURL(fileBlob);
    setRetrievedFileURL(fileURL);
  };

  return (
    <div className="App">
      <h1>Web3.Storage with React</h1>

      <section>
        <h2>Upload</h2>
        <input type="file" onChange={onFileChange} />
        <button onClick={uploadToWeb3}>Upload to Web3.Storage</button>
        {cid && <p>Uploaded with CID: {cid}</p>}
      </section>

      <section>
        <h2>Retrieve & View</h2>
        <button onClick={retrieveFromWeb3}>Retrieve from Web3.Storage</button>
        {retrievedFileURL && (
          <div
            style={{
              border: "1px solid black",
              marginTop: "20px",
              width: "100%",
              height: "400px",
              overflow: "hidden",
            }}
          >
            <embed
              src={retrievedFileURL}
              type="application/pdf"
              style={{ width: "100%", height: "100%", overflow: "hidden" }}
            />
          </div>
        )}
      </section>
    </div>
  );
}

export default PdfViewer;
